report_string = ""
reading_predicted = "prediction.csv"
reading_actual = "log.csv"

# --- BMP masks for image processing ---
mask_full = ""
mask_meridian = ""

# --- Output files for Web display ---
regression_ouput = "regression_goes.php"
prediction_output = "prediction_goes.csv"

